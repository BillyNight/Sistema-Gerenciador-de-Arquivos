var searchData=
[
  ['nomear_26',['nomeAr',['../structparte.html#a737837a1c8550f0319ebb232e3813b38',1,'parte::nomeAr()'],['../structhisto.html#a737837a1c8550f0319ebb232e3813b38',1,'histo::nomeAr()']]]
];
