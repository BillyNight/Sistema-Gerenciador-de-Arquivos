var searchData=
[
  ['parte_31',['Parte',['../_s_g_a_header_8h.html#a9a2fe278fb91f412ec1f155fa7e389cb',1,'SGAHeader.h']]]
];
