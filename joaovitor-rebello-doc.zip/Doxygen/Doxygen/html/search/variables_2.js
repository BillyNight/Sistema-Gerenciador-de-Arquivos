var searchData=
[
  ['prox_27',['prox',['../structparte.html#a89b05155f0f251df065b7f85ffd482b4',1,'parte']]]
];
