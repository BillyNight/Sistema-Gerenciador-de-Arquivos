var searchData=
[
  ['remocao_20',['remocao',['../_s_g_a_header_8h.html#a8d27d99d4a1f8f20e75c9acfc8432352',1,'SGAHeader.h']]]
];
