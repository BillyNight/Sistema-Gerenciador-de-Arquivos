var searchData=
[
  ['index_2',['index',['../structparte.html#a750b5d744c39a06bfb13e6eb010e35d0',1,'parte']]],
  ['indice_3',['indice',['../structhisto.html#aeb5a293641a5914dcff4a1ca75870431',1,'histo']]],
  ['insere_4',['insere',['../_s_g_a_header_8h.html#abe474b2931ee2935e4b3a9074ad11247',1,'SGAHeader.h']]]
];
