var searchData=
[
  ['txt_12',['txt',['../structparte.html#ab13f950e8e17b3e09f6b2eab5d4f469b',1,'parte']]]
];
