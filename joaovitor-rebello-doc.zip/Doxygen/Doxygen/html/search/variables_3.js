var searchData=
[
  ['status_28',['status',['../structhisto.html#a6e27f49150e9a14580fb313cc2777e00',1,'histo']]]
];
