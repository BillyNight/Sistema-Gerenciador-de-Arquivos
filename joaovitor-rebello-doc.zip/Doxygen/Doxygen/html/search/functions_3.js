var searchData=
[
  ['slot_21',['slot',['../_s_g_a_header_8h.html#ab6872624832fe3d5c9bae8cf188c1fa4',1,'SGAHeader.h']]]
];
