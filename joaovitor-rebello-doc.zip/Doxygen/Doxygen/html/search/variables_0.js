var searchData=
[
  ['index_24',['index',['../structparte.html#a750b5d744c39a06bfb13e6eb010e35d0',1,'parte']]],
  ['indice_25',['indice',['../structhisto.html#aeb5a293641a5914dcff4a1ca75870431',1,'histo']]]
];
