var searchData=
[
  ['parte_16',['parte',['../structparte.html',1,'']]]
];
