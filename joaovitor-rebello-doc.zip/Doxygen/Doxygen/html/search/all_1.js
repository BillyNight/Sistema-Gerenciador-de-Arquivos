var searchData=
[
  ['histo_1',['histo',['../structhisto.html',1,'histo'],['../_s_g_a_header_8h.html#aa59f6cf404d3f64b085df5eae7281781',1,'Histo():&#160;SGAHeader.h']]]
];
