var indexSectionsWithContent =
{
  0: "bhinprstvz",
  1: "hp",
  2: "s",
  3: "birsvz",
  4: "inpst",
  5: "hp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Estruturas de Dados",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de Tipos"
};

