var searchData=
[
  ['verif_22',['verif',['../_s_g_a_header_8h.html#a8c2b50801c5f3a8419ea00cec25dd6bb',1,'SGAHeader.h']]]
];
