var searchData=
[
  ['zera_14',['zera',['../_s_g_a_header_8h.html#a08224f9c8c3cf12ddf40cbfc5fe0a568',1,'SGAHeader.h']]]
];
