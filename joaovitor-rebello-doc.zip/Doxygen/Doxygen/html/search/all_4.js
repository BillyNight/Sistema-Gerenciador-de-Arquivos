var searchData=
[
  ['parte_6',['parte',['../structparte.html',1,'parte'],['../_s_g_a_header_8h.html#a9a2fe278fb91f412ec1f155fa7e389cb',1,'Parte():&#160;SGAHeader.h']]],
  ['prox_7',['prox',['../structparte.html#a89b05155f0f251df065b7f85ffd482b4',1,'parte']]]
];
