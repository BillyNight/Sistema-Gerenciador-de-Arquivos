var searchData=
[
  ['sgaheader_2eh_9',['SGAHeader.h',['../_s_g_a_header_8h.html',1,'']]],
  ['slot_10',['slot',['../_s_g_a_header_8h.html#ab6872624832fe3d5c9bae8cf188c1fa4',1,'SGAHeader.h']]],
  ['status_11',['status',['../structhisto.html#a6e27f49150e9a14580fb313cc2777e00',1,'histo']]]
];
